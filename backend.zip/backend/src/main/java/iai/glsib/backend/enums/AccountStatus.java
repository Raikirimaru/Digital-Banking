package iai.glsib.backend.enums;

public enum AccountStatus {
    CREATED,
    SUSPENDED,
    ACTIVATED
}
