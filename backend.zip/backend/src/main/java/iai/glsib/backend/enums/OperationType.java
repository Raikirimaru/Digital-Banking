package iai.glsib.backend.enums;

public enum OperationType {
    CREDIT,
    DEBIT
}
